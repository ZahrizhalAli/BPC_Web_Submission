const mongoose = require("mongoose");

const { ObjectId } = mongoose.Schema;

const userSchema = new mongoose.Schema(
  {
    name: String,
    anggota1: String,
    anggota2: String,
    namatim: String,
    universitas: String,
    jurusan: String,
    category: {
      type: String,
      enum: ["bpc", "bcc"],
    },
    email: {
      type: String,
      required: true,
      index: true,
    },
    role: {
      type: String,
      default: "subscriber",
    },
    sak: {},
    karyaBCC: {},
    karyaBCC2: {},
    karyaBPC: {},
    buktibayar: {},
    gambarktm: {},
    buktitwibbon: {},
    verifikasi: {
      type: Boolean,
      default: false,
    },
    lolostahapdua: {
      type: Boolean,
      default: false,
    },
    isSubmit: {
      type: Boolean,
      default: false,
    },
    //   wishlist: [{ ObjectId, ref: "Product" }],
  },
  { timestamps: true }
);
// timestamps: true = autopopulate date/time of userSchema when saved to collections
module.exports = mongoose.model("User", userSchema);
