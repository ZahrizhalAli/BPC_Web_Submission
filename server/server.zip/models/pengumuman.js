const mongoose = require("mongoose");

const { ObjectId } = mongoose.Schema;

const pengumumanSchema = new mongoose.Schema(
  {
    title: String,
    description: {
      type: String,
      maxlength: 1000,
      text: true,
    },
    file: {},
  },
  { timestamps: true }
);
// timestamps: true = autopopulate date/time of userSchema when saved to collections
module.exports = mongoose.model("Pengumuman", pengumumanSchema);
