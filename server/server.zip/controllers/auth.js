const User = require("../models/user");

exports.createOrUpdateUser = async (req, res) => {
  const { name, email } = req.user; // from authCheck middleware
  const user = await User.findOneAndUpdate({ email }, { new: true });

  if (user) {
    console.log("USER HAS BEEN UPDATED: ", user);
    res.json(user); //send response to front end via res.
  } else {
    const newUser = new User({
      email,
      name,
    });

    newUser.save();
    console.log("USER HAS BEEN CREATED: ", newUser);
    res.json(newUser); //send response to front end via res.
  }
};

exports.currentUser = async (req, res) => {
  //req.user.email came from authCheck middleware.
  User.findOne({ email: req.user.email }).exec((err, user) => {
    if (err) throw new Error(err);
    res.json(user);
  });
};
