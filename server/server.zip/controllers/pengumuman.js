const Pengumuman = require("../models/pengumuman");

exports.createPengumuman = async (req, res) => {
  const { title, description, uploadedfile } = req.body;

  const newPengumuman = new Pengumuman({
    title,
    description,
    file: uploadedfile,
  });

  newPengumuman.save();
  console.log("USER HAS BEEN CREATED: ", newPengumuman);
  res.json(newPengumuman); //send response to front end via res.
};

exports.updatePengumuman = async (req, res) => {
  const { title, description, uploadedfile } = req.body;
  try {
    const updated = await Pengumuman.findOneAndUpdate(
      { _id: req.params.pid },
      {
        title,
        description,
        file: uploadedfile,
      },
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    console.log(err);
    res.status(400).send("Profile update failed");
  }
};

exports.hapusPengumuman = async (req, res) => {
  try {
    const deleted = await Pengumuman.findOneAndDelete({
      _id: req.params.pid,
    }).exec();
    //deleted category
    res.json(deleted);
  } catch (err) {
    console.log(err);
    res.status(400).send("Category delete failed");
  }
};

exports.getPengumuman = async (req, res) => {
  Pengumuman.findOne({ _id: req.params.pid }).exec((err, pengumuman) => {
    if (err) throw new Error(err);
    res.json(pengumuman);
  });
};

exports.getAllPengumuman = async (req, res) => {
  //req.user.email came from authCheck middleware.
  Pengumuman.find({}).exec((err, pengumuman) => {
    if (err) throw new Error(err);
    res.json(pengumuman);
  });
};
