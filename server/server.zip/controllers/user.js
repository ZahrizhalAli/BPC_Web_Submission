const User = require("../models/user");

exports.getUser = async (req, res) => {
  //req.user.email came from authCheck middleware.
  User.findOne({ _id: req.params.userid }).exec((err, user) => {
    if (err) throw new Error(err);
    res.json(user);
  });
};

exports.getAllUser = async (req, res) => {
  //req.user.email came from authCheck middleware.
  User.find({
    role: "subscriber",
    category: req.params.lomba,
  }).exec((err, user) => {
    if (err) throw new Error(err);
    res.json(user);
  });
};

exports.updateUser = async (req, res) => {
  const { email } = req.user; // from authCheck middleware
  console.log(req.body);
  try {
    const updated = await User.findOneAndUpdate(
      { email },
      {
        name: req.body.name,
        anggota1: req.body.anggota1,
        anggota2: req.body.anggota2.length <= 0 ? null : req.body.anggota2,
        namatim: req.body.namatim,
        universitas: req.body.universitas,
        jurusan: req.body.jurusan,
        category: req.body.category,
        gambarktm: req.body.gambarktm,
        buktibayar: req.body.buktibayar,
        sak: req.body.sak,
        buktitwibbon: req.body.twibbon,
        isSubmit: true,
      },
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    console.log(err);
    res.status(400).send("Profile update failed");
  }
};

exports.updateUserBCC = async (req, res) => {
  const { email } = req.user; // from authCheck middleware
  console.log(req.body);
  try {
    const updated = await User.findOneAndUpdate(
      { email },
      {
        karyaBCC: req.body.karyabcc,
      },
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    console.log(err);
    res.status(400).send("Profile update failed");
  }
};

exports.updateUserBCC2 = async (req, res) => {
  const { email } = req.user; // from authCheck middleware
  console.log(req.body);
  try {
    const updated = await User.findOneAndUpdate(
      { email },
      {
        karyaBCC2: req.body.karyabcc2,
      },
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    console.log(err);
    res.status(400).send("Profile update failed");
  }
};

exports.updateUserBPC = async (req, res) => {
  const { email } = req.user; // from authCheck middleware
  console.log(req.body);
  try {
    const updated = await User.findOneAndUpdate(
      { email },
      {
        karyaBPC: req.body.karyabpc,
      },
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    console.log(err);
    res.status(400).send("Profile update failed");
  }
};

exports.updateVerifikasi = async (req, res) => {
  const { email } = req.user; // from authCheck middleware
  console.log(req.body);
  try {
    const updated = await User.findOneAndUpdate(
      { _id: req.body.userid },
      {
        verifikasi: true,
      },
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    console.log(err);
    res.status(400).send("Profile update failed");
  }
};

exports.updateBatalVerifikasi = async (req, res) => {
  const { email } = req.user; // from authCheck middleware
  console.log(req.body);
  try {
    const updated = await User.findOneAndUpdate(
      { _id: req.body.userid },
      {
        verifikasi: false,
      },
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    console.log(err);
    res.status(400).send("Profile update failed");
  }
};

exports.updateTahap2 = async (req, res) => {
  const { email } = req.user; // from authCheck middleware
  try {
    const updated = await User.findOneAndUpdate(
      { _id: req.body.userid },
      {
        lolostahapdua: true,
      },
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    console.log(err);
    res.status(400).send("Profile update failed");
  }
};

exports.updateBatalTahap2 = async (req, res) => {
  const { email } = req.user; // from authCheck middleware
  try {
    const updated = await User.findOneAndUpdate(
      { _id: req.body.userid },
      {
        lolostahapdua: false,
      },
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    console.log(err);
    res.status(400).send("Profile update failed");
  }
};
